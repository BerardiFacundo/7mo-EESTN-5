import { iniciarJuego } from './configuracion';

// Agregar evento al botón de iniciarJuego para comenzar el juego
botonInicio.addEventListener('click', iniciarJuego);