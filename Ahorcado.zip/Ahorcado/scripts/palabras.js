const palabras = [
    "abismo", "acantilado", "albahaca", "alboroto", "alcachofa", "alegría", "alfombra", "alhelí", "almendra", "alondra",
    "amapola", "anacardo", "anémona", "antílope", "apio", "arándano", "arcoíris", "arena", "aroma", "artesano",
    "avellana", "azafrán", "azucena", "bambú", "banquete", "berenjena", "berrendo", "beso", "bisonte", "blanco",
    "bocadillo", "brisa", "burbuja", "caballo", "cactus", "calabaza", "caléndula", "caminante", "cangrejo", "caramelo",
    "cascada", "castaña", "cereza", "cielo", "ciruela", "cisne", "clavel", "cobijo", "colibrí", "cometa",
    "corazón", "corona", "cristal", "dalia", "delfín", "diamante", "dulce", "eco", "elefante", "esmeralda",
    "espuma", "estrella", "flamenco", "flor", "frambuesa", "fresa", "gacela", "girasol", "globo", "golondrina",
    "granada", "guitarra", "helecho", "higo", "horizonte", "jacinto", "jazmín", "jirafa", "lago", "lirio",
    "luna", "mango", "mariposa", "melocotón", "menta", "miel", "montaña", "naranja", "nieve", "nube",
    "orquídea", "palmera", "papaya", "pétalo", "piña", "pluma", "rosa", "ruiseñor", "sándalo", "sol"
];