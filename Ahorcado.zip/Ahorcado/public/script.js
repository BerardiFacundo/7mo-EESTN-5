document.addEventListener('DOMContentLoaded', () => {
    let palabraActual;
    let letrasAdivinadas;
    let intentosRestantes;
    let juegoTerminado;

    const contenedorPalabra = document.getElementById('contenedorPalabra');
    const letrasUsadas = document.getElementById('letrasUsadas');
    const intentosRestantesElement = document.getElementById('intentosRestantes');
    const botonInicio = document.getElementById('botonInicio');

    function obtenerPalabraAleatoria() {
        return fetch('https://random-word-api.herokuapp.com/word?lang=es')
            .then(response => response.json())
            .then(data => data[0])
            .catch(error => {
                console.error('Error al obtener la palabra:', error);
                return 'palabra'; // Palabra por defecto en caso de error
            });
    }

    async function iniciarJuego() {
        palabraActual = await obtenerPalabraAleatoria();
        letrasAdivinadas = new Set();
        intentosRestantes = 6;
        juegoTerminado = false;

        actualizarPalabra();
        actualizarLetrasUsadas();
        actualizarIntentosRestantes();

        document.addEventListener('keydown', manejarTeclaPresionada);
        botonInicio.style.display = 'none';
    }

    function actualizarPalabra() {
        contenedorPalabra.innerHTML = palabraActual
            .split('')
            .map(letra => `<span class="letra ${letrasAdivinadas.has(letra) ? '' : 'hidden'}">${letra}</span>`)
            .join('');
    }

    function actualizarLetrasUsadas() {
        letrasUsadas.textContent = `Letras usadas: ${Array.from(letrasAdivinadas).join(', ')}`;
    }

    function actualizarIntentosRestantes() {
        intentosRestantesElement.textContent = `Intentos restantes: ${intentosRestantes}`;
    }

    function manejarTeclaPresionada(event) {
        if (juegoTerminado) return;

        const letra = event.key.toLowerCase();
        if (letra.length === 1 && letra.match(/[a-zñáéíóú]/)) {
            if (!letrasAdivinadas.has(letra)) {
                letrasAdivinadas.add(letra);
                if (!palabraActual.includes(letra)) {
                    intentosRestantes--;
                }
                actualizarPalabra();
                actualizarLetrasUsadas();
                actualizarIntentosRestantes();
                verificarEstadoJuego();
            }
        }
    }

    function verificarEstadoJuego() {
        const palabraAdivinada = palabraActual
            .split('')
            .every(letra => letrasAdivinadas.has(letra));

        if (palabraAdivinada) {
            juegoTerminado = true;
            alert('¡Ganaste!');
            guardarPuntuacion(100);
        } else if (intentosRestantes === 0) {
            juegoTerminado = true;
            alert(`Perdiste. La palabra era: ${palabraActual}`);
            guardarPuntuacion(0);
        }

        if (juegoTerminado) {
            document.removeEventListener('keydown', manejarTeclaPresionada);
            botonInicio.style.display = 'block';
            botonInicio.textContent = 'Jugar de nuevo';
        }
    }

    function guardarPuntuacion(puntos) {
        const jugador = prompt('Ingresa tu nombre:');
        if (jugador) {
            fetch('/save-score', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ player: jugador, score: puntos }),
            })
            .then(response => response.json())
            .then(data => console.log(data.message))
            .catch(error => console.error('Error:', error));
        }
    }

    botonInicio.addEventListener('click', iniciarJuego);
});